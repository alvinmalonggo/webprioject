document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll("a[href^='#']").forEach(anchor => {
        anchor.addEventListener("click", function(e) {
            e.preventDefault();
            document.querySelector(this.getAttribute("href")).scrollIntoView({
                behavior: "smooth"
            });
        });
    });
});

// Ensure this script runs after the DOM has fully loaded
document.addEventListener('DOMContentLoaded', function () {
    let currentIndex = 0;
    const slides = document.querySelectorAll('.slider img');
    const totalSlides = slides.length;

    // Function to update the slider based on the current index
    function updateSlider() {
        const offset = -currentIndex * 100;  // Move the slider to the current index
        document.querySelector('.slider').style.transform = `translateX(${offset}%)`;  // Apply translation
    }

    // Function to move the slide in the specified direction
    function moveSlide(direction) {
        currentIndex += direction;  // Update the index by the direction (1 for next, -1 for previous)

        // Loop back to first slide if we've reached the end
        if (currentIndex < 0) {
            currentIndex = totalSlides - 1;
        } else if (currentIndex >= totalSlides) {
            currentIndex = 0;
        }

        updateSlider();  // Update the slider position
    }

    // Event listeners for the navigation buttons
    document.querySelector('.next').addEventListener('click', function () {
        moveSlide(1);  // Move forward when next button is clicked
    });

    document.querySelector('.prev').addEventListener('click', function () {
        moveSlide(-1);  // Move backward when prev button is clicked
    });
});
let currentIndex = 0;
const slides = document.querySelectorAll('.slider img');
const totalSlides = slides.length;

function updateSlider() {
    // Remove the 'active' class from all images
    slides.forEach((slide) => {
        slide.classList.remove('active');
    });

    // Add the 'active' class to the currently focused image
    slides[currentIndex].classList.add('active');
}

function moveSlide(direction) {
    // Increment or decrement the current index
    currentIndex += direction;

    // Loop around if we go past the first or last image
    if (currentIndex < 0) {
        currentIndex = totalSlides - 1; // Go to the last image if we're at the beginning
    } else if (currentIndex >= totalSlides) {
        currentIndex = 0; // Go to the first image if we're at the end
    }

    // Update the slider to show the new active image
    updateSlider();
}

// Initialize the slider by focusing on the first image
updateSlider();
